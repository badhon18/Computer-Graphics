#include<windows.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>

int serial=0;
static void Timer(int value)
{
    serial += 1;

    glutPostRedisplay();
    // 100 milliseconds
    glutTimerFunc(1000, Timer, 0);
}
void delay(){
    for(int i=0;i<100000000;i++);
}
void fullcircle(GLfloat rx, GLfloat ry, GLfloat x, GLfloat y)
{
    int i=0;
    float angle;
    GLfloat PI= 2.0f * 3.1416;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x,y);
    for(i=0;i<100;i++)
    {
        angle = 2 * PI * i/100;
        glVertex2f(x+(cos(angle)*rx),y+(sin(angle)* ry));
    }
    glEnd();
}
void halfcircledown(GLfloat rx, GLfloat ry, GLfloat x, GLfloat y)
{
    int i=0;
    float angle;
    GLfloat PI= 2.0f * 3.1416;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x,y);
    for(i=0;i<100;i++)
    {
        angle = 2 * PI * i/100;
        angle=angle/-3.95;
        glVertex2f(x+(cos(angle)*rx),y+(sin(angle)* ry));
    }
    glEnd();
}
void halfcircleup(GLfloat rx, GLfloat ry, GLfloat x, GLfloat y)
{
    int i=0;
    float angle;
    GLfloat PI= 2.0f * 3.1416;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x,y);
    for(i=0;i<100;i++)
    {
        angle = 2 * PI * i/100;
        angle=angle/3.95;
        glVertex2f(x+(cos(angle)*rx),y+(sin(angle)* ry));
    }
    glEnd();
}
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT| GL_DEPTH_BUFFER_BIT);
    delay();
    //kan
     glColor3ub(0,0,0);
    fullcircle(5,5,35,84);
    fullcircle(5,5,65,84);


    glColor3ub(0,0,0);
    fullcircle(25,20,50,50);
     glColor3ub(255,255,255);
    fullcircle(18,12,50,73);
 //eye
    glColor3ub(0,0,0);
    fullcircle(4,4,45,75);
    fullcircle(4,4,55,75);
     glColor3ub(255,255,255);
    fullcircle(2,2,45,75);
    fullcircle(2,2,55,75);
    glColor3ub(0,0,0);
    fullcircle(1,1,45,75);
    fullcircle(1,1,55,75);
    glBegin(GL_POLYGON);
    glVertex2d(47,70);
    glVertex2d(54,70);
    glVertex2d(50.5,68);
    glEnd();
    glColor3f(1,0,0);
    halfcircledown(3,2,50.5,67);
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);
    glVertex2d(28,56);
    glVertex2d(72,56);
    glVertex2d(72,41);
    glVertex2d(28,41);
    glEnd();
    fullcircle(5,7,29,49);
    fullcircle(5,7.4,70,48.5);
    //leg
    glColor3f(0,0,0);
    fullcircle(5,7,40,31);
    fullcircle(5,7,55,31);
	glFlush();
}

void init(void)
{
	glClearColor (1, 1, 0, 0);
	glOrtho(0, 100.0, 0, 100.0, 0, 100.0);
}



int main()
{
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (0, 0);
	glutCreateWindow ("panda");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}

